-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.SerializationKt
-keep,includedescriptorclasses class com.arena.geminiagent.**$$serializer { *; }
-keepclassmembers class com.arena.geminiagent.** {
    *** Companion;
}
-keepclasseswithmembers class com.arena.geminiagent.** {
    kotlinx.serialization.KSerializer serializer(...);
}
