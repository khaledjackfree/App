package com.arena.geminiagent.util

import android.util.Log

/** Tiny tag-prefixed logger. */
object L {
    private const val TAG = "GemAgent"
    fun d(msg: String) = Log.d(TAG, msg)
    fun i(msg: String) = Log.i(TAG, msg)
    fun w(msg: String) = Log.w(TAG, msg)
    fun e(msg: String, t: Throwable? = null) = Log.e(TAG, msg, t)
}
