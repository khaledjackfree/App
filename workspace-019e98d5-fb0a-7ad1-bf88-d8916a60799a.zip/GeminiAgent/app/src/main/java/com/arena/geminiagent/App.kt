package com.arena.geminiagent

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_AGENT, getString(R.string.channel_agent),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_OVERLAY, getString(R.string.channel_overlay),
                    NotificationManager.IMPORTANCE_MIN
                )
            )
        }
    }

    companion object {
        const val CHANNEL_AGENT = "agent_channel"
        const val CHANNEL_OVERLAY = "overlay_channel"
    }
}
