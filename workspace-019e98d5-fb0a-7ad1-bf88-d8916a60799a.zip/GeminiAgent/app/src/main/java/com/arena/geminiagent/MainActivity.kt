package com.arena.geminiagent

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.arena.geminiagent.data.Settings
import com.arena.geminiagent.screen.ScreenCapturer
import com.arena.geminiagent.service.AgentService
import com.arena.geminiagent.service.OverlayService
import com.arena.geminiagent.ui.GeminiAgentTheme
import com.arena.geminiagent.ui.HomeScreen
import com.arena.geminiagent.ui.HomeState
import com.arena.geminiagent.ui.SettingsScreen
import kotlinx.coroutines.flow.MutableStateFlow

class MainActivity : ComponentActivity() {

    private var boundService: AgentService? = null
    private val boundFlow = MutableStateFlow<AgentService?>(null)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            boundService = (service as AgentService.LocalBinder).service
            boundFlow.value = boundService
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            boundService = null; boundFlow.value = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Bind to the service WITHOUT auto-creating it. If it isn't running yet,
        // the connection will simply not fire — we'll bind again right after
        // we start the service from the UI.
        try {
            bindService(Intent(this, AgentService::class.java), connection, 0)
        } catch (_: Exception) {}

        setContent {
            GeminiAgentTheme { AppNav() }
        }
    }

    override fun onDestroy() {
        try { unbindService(connection) } catch (_: Exception) {}
        super.onDestroy()
    }

    @Composable
    private fun AppNav() {
        val nav = rememberNavController()
        val ctx = LocalContext.current
        val settings = remember { Settings(ctx) }

        NavHost(nav, startDestination = "home") {
            composable("home") {
                HomeRoute(
                    settings = settings,
                    openSettings = { nav.navigate("settings") }
                )
            }
            composable("settings") {
                SettingsScreen(settings = settings, onBack = { nav.popBackStack() })
            }
        }
    }

    @Composable
    private fun HomeRoute(settings: Settings, openSettings: () -> Unit) {
        val ctx = LocalContext.current
        val service by boundFlow.collectAsState()
        val status by (service?.status ?: MutableStateFlow(AgentService.Status.Idle))
            .collectAsState(initial = AgentService.Status.Idle)
        val caption by (service?.caption ?: MutableStateFlow(""))
            .collectAsState(initial = "")

        var pendingPermissions by remember { mutableStateOf(false) }

        val micLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { results ->
            if (results.values.all { it }) {
                pendingPermissions = true
            }
        }

        val projectionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            // Start service even if user denied projection — agent works without screen too.
            AgentService.start(
                ctx,
                mpCode = if (result.resultCode == Activity.RESULT_OK) result.resultCode else 0,
                mpData = if (result.resultCode == Activity.RESULT_OK) result.data else null
            )
            // Rebind to get updated service ref
            try {
                ctx.bindService(Intent(ctx, AgentService::class.java), connection, 0)
            } catch (_: Exception) {}
            if (settings.showOverlay && AndroidSettings.canDrawOverlays(ctx)) {
                OverlayService.start(ctx)
            }
        }

        LaunchedEffect(pendingPermissions) {
            if (pendingPermissions) {
                pendingPermissions = false
                // Ask for overlay permission if missing
                if (settings.showOverlay && !AndroidSettings.canDrawOverlays(ctx)) {
                    val i = Intent(
                        AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${ctx.packageName}")
                    )
                    ctx.startActivity(i)
                    return@LaunchedEffect
                }
                // Request screen capture if streaming enabled
                if (settings.streamScreen) {
                    projectionLauncher.launch(ScreenCapturer.buildPermissionIntent(ctx))
                } else {
                    AgentService.start(ctx, mpCode = 0, mpData = null)
                    if (settings.showOverlay && AndroidSettings.canDrawOverlays(ctx)) {
                        OverlayService.start(ctx)
                    }
                }
            }
        }

        DisposableEffect(Unit) {
            onDispose { }
        }

        val running = status != AgentService.Status.Idle && status != AgentService.Status.Error
        val (label, color) = when (status) {
            AgentService.Status.Idle -> "غير نشط" to Color(0xFF8C8CA0)
            AgentService.Status.Connecting -> "جاري الاتصال…" to Color(0xFF0288D1)
            AgentService.Status.Listening -> "يستمع" to Color(0xFF00C853)
            AgentService.Status.Speaking -> "يتحدث…" to Color(0xFFFFA000)
            AgentService.Status.Thinking -> "يفكر…" to Color(0xFF0288D1)
            AgentService.Status.Error -> "خطأ في الاتصال" to Color(0xFFE53935)
        }

        HomeScreen(
            state = HomeState(
                running = running,
                statusLabel = label,
                statusColor = color,
                caption = caption,
                apiKeySet = settings.apiKey.isNotBlank()
            ),
            onStart = {
                val perms = buildList {
                    add(Manifest.permission.RECORD_AUDIO)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                        add(Manifest.permission.POST_NOTIFICATIONS)
                }.toTypedArray()
                val allGranted = perms.all {
                    ContextCompat.checkSelfPermission(ctx, it) ==
                            android.content.pm.PackageManager.PERMISSION_GRANTED
                }
                if (allGranted) pendingPermissions = true else micLauncher.launch(perms)
            },
            onStop = {
                AgentService.stop(ctx)
                OverlayService.stop(ctx)
            },
            onTalkNow = { AgentService.arm(ctx) },
            onOpenSettings = openSettings
        )
    }
}
