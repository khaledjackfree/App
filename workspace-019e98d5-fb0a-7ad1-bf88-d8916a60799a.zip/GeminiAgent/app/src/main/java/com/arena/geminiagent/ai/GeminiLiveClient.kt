package com.arena.geminiagent.ai

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.concurrent.TimeUnit

/**
 * Gemini Live API client over WebSocket.
 *
 * Wire protocol (BidiGenerateContent over WS):
 *   wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=API_KEY
 *
 *  1) Client sends initial `setup` message (model, system instruction, response modality, voice...)
 *  2) Server replies with `setupComplete`.
 *  3) Then bidirectional streaming via `realtimeInput` (audio/video/text) ⇄ `serverContent` (audio out, transcripts, interruption).
 *
 * Audio in : 16-bit PCM little-endian, 16 kHz, mono, base64 in JSON, MIME `audio/pcm;rate=16000`.
 * Audio out: 16-bit PCM little-endian, 24 kHz, mono — fed directly to AudioTrack.
 * Video    : JPEG frames (image/jpeg), <= 1 FPS.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val model: String,
    private val systemInstruction: String,
    private val voice: String = "Puck",
    private val languageCode: String = "ar-EG"
) {

    enum class State { Idle, Connecting, Ready, Reconnecting, Closed, Error }

    private val _state = MutableStateFlow(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    /** Raw 24kHz PCM chunks received from the model (to be played back). */
    private val _audioOut = MutableSharedFlow<ByteArray>(extraBufferCapacity = 64)
    val audioOut: SharedFlow<ByteArray> = _audioOut.asSharedFlow()

    /** Transcripts (both input from user and output from model). */
    private val _transcripts = MutableSharedFlow<Transcript>(extraBufferCapacity = 32)
    val transcripts: SharedFlow<Transcript> = _transcripts.asSharedFlow()

    /** Server signals the user interrupted — caller should flush the playback queue. */
    private val _interrupted = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    val interrupted: SharedFlow<Unit> = _interrupted.asSharedFlow()

    data class Transcript(val text: String, val fromUser: Boolean, val final: Boolean)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var keepAliveJob: Job? = null
    private var ws: WebSocket? = null
    private var reconnectAttempt = 0
    private var manuallyClosed = false

    private val httpClient = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // streaming
        .build()

    // ───────────────────────────── Public API ─────────────────────────────

    fun connect() {
        if (_state.value == State.Connecting || _state.value == State.Ready) return
        manuallyClosed = false
        openSocket()
    }

    fun close() {
        manuallyClosed = true
        keepAliveJob?.cancel()
        ws?.close(1000, "client_close")
        ws = null
        _state.value = State.Closed
        scope.cancel()
    }

    /** Send a raw PCM audio chunk (16-bit LE, 16 kHz, mono). Fire-and-forget. */
    fun sendAudio(pcm16: ByteArray) {
        val ws = ws ?: return
        if (_state.value != State.Ready) return
        val b64 = Base64.encodeToString(pcm16, Base64.NO_WRAP)
        val msg = buildJsonObject {
            put("realtime_input", buildJsonObject {
                put("audio", buildJsonObject {
                    put("data", b64)
                    put("mime_type", "audio/pcm;rate=16000")
                })
            })
        }
        ws.send(msg.toString())
    }

    /** Send one screen/video frame as JPEG bytes. */
    fun sendVideoFrame(jpegBytes: ByteArray) {
        val ws = ws ?: return
        if (_state.value != State.Ready) return
        val b64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
        val msg = buildJsonObject {
            put("realtime_input", buildJsonObject {
                put("video", buildJsonObject {
                    put("data", b64)
                    put("mime_type", "image/jpeg")
                })
            })
        }
        ws.send(msg.toString())
    }

    /** Send a text turn (push-to-talk fallback). */
    fun sendText(text: String) {
        val ws = ws ?: return
        if (_state.value != State.Ready) return
        val msg = buildJsonObject {
            put("realtime_input", buildJsonObject {
                put("text", text)
            })
        }
        ws.send(msg.toString())
    }

    /** Explicitly mark start/end of a user speech segment (when wake-word is gating). */
    fun sendActivityStart() {
        val ws = ws ?: return
        ws.send(buildJsonObject {
            put("realtime_input", buildJsonObject {
                put("activity_start", buildJsonObject {})
            })
        }.toString())
    }
    fun sendActivityEnd() {
        val ws = ws ?: return
        ws.send(buildJsonObject {
            put("realtime_input", buildJsonObject {
                put("activity_end", buildJsonObject {})
            })
        }.toString())
    }

    // ───────────────────────────── Internals ─────────────────────────────

    private fun openSocket() {
        _state.value = State.Connecting
        val url =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()
        ws = httpClient.newWebSocket(request, listener)
    }

    private fun scheduleReconnect() {
        if (manuallyClosed) return
        reconnectAttempt++
        val delayMs = (1000L * (1 shl reconnectAttempt.coerceAtMost(5))).coerceAtMost(30_000L)
        Log.w(TAG, "Reconnecting in ${delayMs}ms (attempt $reconnectAttempt)")
        _state.value = State.Reconnecting
        scope.launch {
            delay(delayMs)
            if (!manuallyClosed) openSocket()
        }
    }

    private fun sendSetup(ws: WebSocket) {
        // Voice config — Gemini Live supports a prebuilt voice name + language hint.
        val setup = buildJsonObject {
            put("setup", buildJsonObject {
                put("model", "models/$model")
                put("system_instruction", buildJsonObject {
                    put("parts", buildJsonArray {
                        add(buildJsonObject { put("text", systemInstruction) })
                    })
                })
                put("generation_config", buildJsonObject {
                    put("response_modalities", buildJsonArray { add("AUDIO") })
                    put("speech_config", buildJsonObject {
                        put("voice_config", buildJsonObject {
                            put("prebuilt_voice_config", buildJsonObject {
                                put("voice_name", voice)
                            })
                        })
                        put("language_code", languageCode)
                    })
                    // Lower thinking budget = snappier real-time replies.
                    put("thinking_config", buildJsonObject {
                        put("thinking_budget", 0)
                    })
                })
                // Enable BOTH input + output transcriptions (so UI can show captions).
                put("input_audio_transcription", buildJsonObject {})
                put("output_audio_transcription", buildJsonObject {})
                // Lower media resolution → fewer tokens for screen frames.
                put("media_resolution", "MEDIA_RESOLUTION_LOW")
                // Realtime input config — let server's VAD decide turns automatically.
                put("realtime_input_config", buildJsonObject {
                    put("automatic_activity_detection", buildJsonObject {
                        put("disabled", false)
                    })
                })
            })
        }
        ws.send(setup.toString())
    }

    private val listener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.i(TAG, "WS open")
            sendSetup(webSocket)
            // Heartbeat — keep idle connections alive on cellular networks.
            keepAliveJob?.cancel()
            keepAliveJob = scope.launch {
                while (true) {
                    delay(15_000)
                    webSocket.send(ByteString.EMPTY)
                }
            }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            handleJson(text)
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            // Server can also send binary frames containing JSON.
            handleJson(bytes.utf8())
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Log.w(TAG, "WS closing: $code $reason")
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.w(TAG, "WS closed: $code $reason")
            keepAliveJob?.cancel()
            if (!manuallyClosed) {
                _state.value = State.Closed
                scheduleReconnect()
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e(TAG, "WS failure: ${t.message}", t)
            keepAliveJob?.cancel()
            _state.value = State.Error
            if (!manuallyClosed) scheduleReconnect()
        }
    }

    private fun handleJson(raw: String) {
        if (raw.isBlank()) return
        try {
            val json = kotlinx.serialization.json.Json.parseToJsonElement(raw) as? JsonObject ?: return

            json["setupComplete"]?.let {
                Log.i(TAG, "setupComplete")
                _state.value = State.Ready
                reconnectAttempt = 0
                return
            }

            val serverContent = json["serverContent"] as? JsonObject ?: return

            // Interruption — user spoke while model was talking. Flush playback.
            (serverContent["interrupted"] as? kotlinx.serialization.json.JsonPrimitive)?.let { p ->
                if (p.content == "true") {
                    scope.launch { _interrupted.emit(Unit) }
                }
            }

            // Audio + text parts inside modelTurn.parts
            val modelTurn = serverContent["modelTurn"] as? JsonObject
            (modelTurn?.get("parts") as? kotlinx.serialization.json.JsonArray)?.forEach { part ->
                val partObj = part as? JsonObject ?: return@forEach
                val inline = partObj["inlineData"] as? JsonObject
                if (inline != null) {
                    val mime =
                        (inline["mimeType"] as? kotlinx.serialization.json.JsonPrimitive)?.content
                    val data =
                        (inline["data"] as? kotlinx.serialization.json.JsonPrimitive)?.content
                    if (data != null && mime != null && mime.startsWith("audio/")) {
                        val pcm = Base64.decode(data, Base64.DEFAULT)
                        scope.launch { _audioOut.emit(pcm) }
                    }
                }
                val txt = (partObj["text"] as? kotlinx.serialization.json.JsonPrimitive)?.content
                if (!txt.isNullOrEmpty()) {
                    scope.launch {
                        _transcripts.emit(Transcript(txt, fromUser = false, final = false))
                    }
                }
            }

            // Transcriptions
            (serverContent["inputTranscription"] as? JsonObject)?.let {
                val t = (it["text"] as? kotlinx.serialization.json.JsonPrimitive)?.content
                if (!t.isNullOrEmpty()) scope.launch {
                    _transcripts.emit(Transcript(t, fromUser = true, final = false))
                }
            }
            (serverContent["outputTranscription"] as? JsonObject)?.let {
                val t = (it["text"] as? kotlinx.serialization.json.JsonPrimitive)?.content
                if (!t.isNullOrEmpty()) scope.launch {
                    _transcripts.emit(Transcript(t, fromUser = false, final = false))
                }
            }

            // turnComplete
            (serverContent["turnComplete"] as? kotlinx.serialization.json.JsonPrimitive)?.let {
                if (it.content == "true") {
                    scope.launch {
                        _transcripts.emit(Transcript("", fromUser = false, final = true))
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Bad JSON: ${e.message}\n$raw")
        }
    }

    companion object { private const val TAG = "GeminiLive" }
}
