package com.arena.geminiagent.service

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import com.arena.geminiagent.App
import com.arena.geminiagent.MainActivity
import com.arena.geminiagent.R

/**
 * Floating draggable button that sits on top of all apps (including games).
 * Tap → arms the agent for a few seconds (so anything you say next gets sent).
 * Long-press → toggles drag mode (button stays at the location where you release).
 */
class OverlayService : Service() {

    private var view: View? = null
    private var wm: WindowManager? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startInForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { teardown(); stopSelf() }
            else -> showBubble()
        }
        return START_STICKY
    }

    private fun showBubble() {
        if (view != null) return
        if (!AndroidSettings.canDrawOverlays(this)) {
            stopSelf(); return
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_button, null) as FrameLayout
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40; y = 300
        }

        var initialX = 0; var initialY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX = e.rawX; touchY = e.rawY; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) moved = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    wm?.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        // Tap → arm the agent
                        AgentService.arm(this@OverlayService)
                    }
                    true
                }
                else -> false
            }
        }
        wm?.addView(v, params)
        view = v
    }

    private fun teardown() {
        try { view?.let { wm?.removeView(it) } } catch (_: Exception) {}
        view = null
    }

    override fun onDestroy() { teardown(); super.onDestroy() }

    private fun startInForeground() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(this, App.CHANNEL_OVERLAY)
            .setSmallIcon(R.drawable.ic_agent)
            .setContentTitle(getString(R.string.notif_overlay_title))
            .setContentText(getString(R.string.notif_overlay_text))
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIF_ID, notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    companion object {
        private const val NOTIF_ID = 4343
        const val ACTION_STOP = "com.arena.geminiagent.OVERLAY_STOP"

        fun start(context: Context) {
            context.startForegroundService(Intent(context, OverlayService::class.java))
        }
        fun stop(context: Context) {
            context.startService(
                Intent(context, OverlayService::class.java).setAction(ACTION_STOP)
            )
        }
    }
}
