package com.arena.geminiagent.screen

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

/**
 * Captures the device screen via MediaProjection and emits down-scaled JPEG frames
 * at the configured FPS (capped at 1 FPS, the Live API maximum).
 *
 * Captured frames target ~768x768 long-edge (Google's recommendation for best
 * comprehension at low token cost).
 *
 * IMPORTANT: caller must obtain a MediaProjection Intent via the
 * MediaProjectionManager dance from an Activity, then start the host
 * foreground service BEFORE calling [start]. Without that, Android 14+
 * will throw `SecurityException`.
 */
class ScreenCapturer(
    private val context: Context,
    private val mediaProjection: MediaProjection,
    private val fps: Float = 1.0f,
    private val targetLongEdge: Int = 768,
    private val jpegQuality: Int = 70
) {

    private val _frames = MutableSharedFlow<ByteArray>(extraBufferCapacity = 2)
    val frames: SharedFlow<ByteArray> = _frames.asSharedFlow()

    private val handlerThread = HandlerThread("ScreenCap").apply { start() }
    private val handler = Handler(handlerThread.looper)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var captureJob: Job? = null
    private var captureWidth = 0
    private var captureHeight = 0
    private val intervalMs: Long = (1000.0 / fps.coerceIn(0.2f, 1.0f)).toLong()

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { Log.w(TAG, "MediaProjection stopped by system") }
    }

    fun start() {
        if (imageReader != null) return
        mediaProjection.registerCallback(projectionCallback, handler)

        val metrics = DisplayMetrics()
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        // Scale down for transport efficiency.
        val maxEdge = maxOf(metrics.widthPixels, metrics.heightPixels).toFloat()
        val scale = (targetLongEdge.toFloat() / maxEdge).coerceAtMost(1.0f)
        captureWidth = (metrics.widthPixels * scale).toInt().coerceAtLeast(64)
        captureHeight = (metrics.heightPixels * scale).toInt().coerceAtLeast(64)

        val reader = ImageReader.newInstance(
            captureWidth, captureHeight, PixelFormat.RGBA_8888, 2
        )
        imageReader = reader

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "GeminiAgentScreen",
            captureWidth, captureHeight, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )

        // Pull frames at the requested rate (not on every onImageAvailable to avoid burst).
        captureJob = scope.launch {
            while (true) {
                grabOneFrame()?.let { _frames.tryEmit(it) }
                delay(intervalMs)
            }
        }
    }

    private fun grabOneFrame(): ByteArray? {
        val reader = imageReader ?: return null
        val image: Image = try { reader.acquireLatestImage() ?: return null }
        catch (e: Exception) { Log.e(TAG, "acquire failed: ${e.message}"); return null }

        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * captureWidth
            val bmp = Bitmap.createBitmap(
                captureWidth + rowPadding / pixelStride, captureHeight,
                Bitmap.Config.ARGB_8888
            )
            bmp.copyPixelsFromBuffer(buffer)
            val cropped = if (rowPadding == 0) bmp
            else Bitmap.createBitmap(bmp, 0, 0, captureWidth, captureHeight)

            val baos = ByteArrayOutputStream()
            cropped.compress(Bitmap.CompressFormat.JPEG, jpegQuality, baos)
            if (cropped !== bmp) cropped.recycle()
            bmp.recycle()
            baos.toByteArray()
        } catch (e: Exception) {
            Log.e(TAG, "encode failed: ${e.message}")
            null
        } finally {
            try { image.close() } catch (_: Exception) {}
        }
    }

    fun stop() {
        captureJob?.cancel(); captureJob = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { mediaProjection.unregisterCallback(projectionCallback) } catch (_: Exception) {}
        try { mediaProjection.stop() } catch (_: Exception) {}
        virtualDisplay = null
        imageReader = null
    }

    fun shutdown() {
        stop()
        scope.cancel()
        handlerThread.quitSafely()
    }

    companion object {
        private const val TAG = "ScreenCapturer"

        /** Build the system Intent used to request screen capture permission. */
        fun buildPermissionIntent(context: Context): Intent {
            val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                    as MediaProjectionManager
            return mpm.createScreenCaptureIntent()
        }

        /** Turn the Activity result back into a MediaProjection. */
        fun fromActivityResult(context: Context, resultCode: Int, data: Intent): MediaProjection? {
            val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                    as MediaProjectionManager
            return mpm.getMediaProjection(resultCode, data)
        }
    }
}
