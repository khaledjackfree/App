# 🤖 Gemini Live Agent – وكيل ذكاء اصطناعي حي على أندرويد

تطبيق أندرويد متقدم يحوّل هاتفك إلى **رفيق ذكاء اصطناعي صوتي حقيقي** يراقب شاشتك أثناء اللعب أو العمل ويرد عليك بصوت طبيعي — دون مغادرة لعبتك.

مبني باستخدام **Kotlin + Jetpack Compose + Gemini Live API** (أحدث نموذج `gemini-3.1-flash-live-preview` من عائلة Gemini 3.5 المعلنة في Google I/O 2026)، مع إمكانية التبديل لـ `gemini-3.5-flash` للأسئلة المعقدة.

---

## ✨ المميزات الأساسية

| الميزة | الوصف |
|---|---|
| 🎥 **مراقبة الشاشة الحية** | يلتقط لقطات شاشة بمعدل قابل للتعديل (افتراضي 1 FPS) ويرسلها لـ Gemini عبر WebSocket في الوقت الفعلي |
| 🎤 **مايك مفتوح دائماً** | يستمع باستمرار بـ 16 kHz PCM ويرسل الصوت مباشرة (مع VAD أصلي من Gemini) |
| 🔊 **رد صوتي طبيعي فوري** | إخراج صوتي native بـ 24 kHz PCM يُشغّل عبر AudioTrack بأقل تأخير ممكن |
| 🛑 **يتكلم فقط لما تكلمه** | System Instruction صارمة + Wake Word ("يا جيمناي" / "Hey Gemini") + زر عائم Push-to-Talk |
| 🪟 **زر عائم Overlay** | يطفو فوق أي لعبة/تطبيق — تضغطه فيتكلم، أو يبقى صامت تلقائياً |
| ⚙️ **خدمة Foreground دائمة** | يستمر بالعمل في الخلفية مع إشعار دائم |
| 🔐 **مفتاح API محلي** | يُخزَّن في EncryptedSharedPreferences — لا يغادر جهازك أبداً |
| 🧠 **نموذجان قابلان للتبديل** | Live (للحوار الصوتي) + 3.5 Flash (للتفكير العميق في screenshot واحد) |
| 🎙️ **اختيار الصوت** | 30+ صوتاً أصلياً من Gemini (Puck, Charon, Kore, Fenrir, Aoede ...) |
| 🌍 **يدعم العربية بالكامل** | UI عربي + الموديل يرد بالعربي (مع كشف اللغة تلقائياً) |

---

## 🏗️ المعمارية

```
┌──────────────────────────────────────────────────────────────┐
│                       MainActivity                            │
│              (Jetpack Compose UI + إعدادات)                  │
└───────────────┬───────────────────────────┬──────────────────┘
                │                           │
        ┌───────▼────────┐         ┌────────▼────────┐
        │ OverlayService │         │  AgentService   │
        │ (زر عائم +     │◄───────►│  (Foreground)   │
        │  Wake Word)    │         │                 │
        └────────────────┘         └────┬────────────┘
                                        │
                  ┌─────────────────────┼─────────────────────┐
                  │                     │                     │
          ┌───────▼──────┐     ┌────────▼────────┐    ┌──────▼─────┐
          │ScreenCapturer│     │AudioStreamer    │    │GeminiLive  │
          │(MediaProj.)  │     │(Record+Track)   │    │Client (WS) │
          │  → JPEG 1fps │     │ 16k in/24k out  │    │            │
          └──────────────┘     └─────────────────┘    └──────┬─────┘
                                                            │
                                              ┌─────────────▼──────────┐
                                              │  Gemini Live API       │
                                              │ gemini-3.1-flash-live  │
                                              │      -preview          │
                                              └────────────────────────┘
```

---

## 📦 المتطلبات

- Android Studio Hedgehog (2025.1.x) أو أحدث
- minSdk 26 (Android 8.0) – targetSdk 35 (Android 15)
- Kotlin 2.0.20+
- مفتاح API من [Google AI Studio](https://aistudio.google.com/apikey) (مجاني – tier مجاني يكفي للتجربة)

---

## 🚀 خطوات التشغيل

1. افتح المجلد `GeminiAgent` في Android Studio.
2. انتظر Gradle sync (سيُحمّل المكتبات تلقائياً).
3. اضغط Run ▶️ على جهاز حقيقي (المحاكي لا يدعم MediaProjection جيداً).
4. أول مرة فقط:
   - **Settings → API Key**: ضع مفتاحك من AI Studio.
   - **Permissions**: اقبل صلاحيات الميكروفون + الإشعارات + Overlay.
5. اضغط **"بدء الوكيل"** → اقبل طلب تسجيل الشاشة → سيظهر زر عائم على شاشتك.
6. شغّل أي لعبة/تطبيق وقل: **"يا جيمناي، شو رأيك ألعب أنهي شخصية؟"** — هيرد عليك بصوت!

---

## 🎛️ التحكم في سلوك الوكيل

| الإعداد | الافتراضي | الوصف |
|---|---|---|
| Speak Mode | `On Request Only` | الوكيل يرد فقط عند ندائه (لا يتطفل) |
| Wake Word | `يا جيمناي` | كلمة التنبيه — قابلة للتعديل |
| Screen FPS | `1.0` | لقطات شاشة في الثانية (الحد الأقصى للـ Live API) |
| Voice | `Puck` | صوت الإخراج |
| Language Hint | `Arabic` | للسرعة في الكشف |
| Thinking Level | `low` | للحوار السريع — ارفعه للأسئلة المعقدة |

---

## 🔑 ملاحظات تقنية مهمة

- **Live API** يستخدم WebSocket. التطبيق يدير الاتصال بـ OkHttp WebSocketClient ويعيد الاتصال تلقائياً عند الانقطاع.
- **الفيديو/الشاشة** ترسل كـ JPEG مفردة بحد أقصى 1 FPS (هذا حد Google الرسمي للأداء الأمثل).
- **الصوت Input**: PCM خام، 16-bit، 16 kHz، mono، little-endian.
- **الصوت Output**: PCM خام، 16-bit، 24 kHz، mono — يُشغَّل عبر `AudioTrack` في وضع streaming.
- **VAD**: مفعّل تلقائياً من سيرفر Gemini — يقاطع نفسه لو اتكلمت أثناء حديثه.
- **System Instruction**: مُصمَّمة بعناية لتجعله صامتاً افتراضياً.

---

## 📂 بنية المشروع

```
app/src/main/
├── AndroidManifest.xml
├── java/com/arena/geminiagent/
│   ├── App.kt                          ← Application class
│   ├── MainActivity.kt                 ← Compose UI الرئيسي
│   ├── ui/
│   │   ├── HomeScreen.kt
│   │   ├── SettingsScreen.kt
│   │   └── Theme.kt
│   ├── service/
│   │   ├── AgentService.kt             ← Foreground service الأساسية
│   │   └── OverlayService.kt           ← الزر العائم
│   ├── ai/
│   │   ├── GeminiLiveClient.kt         ← WebSocket client لـ Live API
│   │   ├── GeminiRestClient.kt         ← لـ gemini-3.5-flash REST
│   │   └── SystemPrompt.kt
│   ├── audio/
│   │   ├── AudioRecorder.kt            ← 16kHz PCM capture
│   │   ├── AudioPlayer.kt              ← 24kHz PCM playback
│   │   └── WakeWordDetector.kt         ← كشف كلمة التنبيه
│   ├── screen/
│   │   └── ScreenCapturer.kt           ← MediaProjection + JPEG
│   ├── data/
│   │   └── Settings.kt                 ← EncryptedSharedPreferences
│   └── util/
│       ├── Logger.kt
│       └── Extensions.kt
└── res/
    ├── layout/overlay_button.xml
    ├── values/{strings,colors,themes}.xml
    ├── drawable/ic_*.xml
    └── xml/file_paths.xml
```

---

صُنع بـ ❤️ على Arena.ai
